-------
Content
-------

Use HMMER & SumaClust to generate representative tRNA database for SortMeRNA metatranscriptomic read filtering.


-------
Methods
-------

1. RFAM tRNA, tmRNA, alpha-tmRNA, beta-tmRNA, cyano-tmRNA, tRNA-Sec, mt-tmRNA available on ftp://ftp.ebi.ac.uk/pub/databases/Rfam/12.0/fasta_files/

file	family	origin	# seq (original)
RF01852.fa 	tRNA-Sec	RFAM/12.0	2184
RF01851.fa	cyano-tmRNA	RFAM/12.0	190
RF00023.fa 	tmRNA   	RFAM/12.0	6350
RF02544.fa	mt-tmRNA	RFAM/12.0	66
RF01850.fa	beta-tmRNA	RFAM/12.0	51
RF01849.fa	alpha-tmRNA	RFAM/12.0	2078
RF00005.fa	tRNA    	RFAM/12.0	1760237



if necessary:

2.Use SumaClust version 1.0.00 to cluster sequences for the file RF00005.fa

3.Extract only the cluster centers
